import './App.css';
import Nav from './Nav';
import Logo from './Logo';

function App() {

    return ( 
        <><Nav/>
        <Logo/>
        </>
    );
}

export default App;